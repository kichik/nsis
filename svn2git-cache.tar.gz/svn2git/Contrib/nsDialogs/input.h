// Reviewed for Unicode support by Jim Park -- 08/24/2007

#ifndef __NS_DIALOGS__INPUT_H__
#define __NS_DIALOGS__INPUT_H__

#include "defs.h"

int NSDFUNC PopPlacement(int *x, int *y, int *width, int *height);

#endif//__NS_DIALOGS__INPUT_H__
